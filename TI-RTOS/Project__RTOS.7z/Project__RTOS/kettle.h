#ifndef KETTLE_H_
#define KETTLE_H_

#define DELTA_T 0.01
#define DELTA_TEMPERATURE (10.0 * DELTA_T)
#define ENVIRONMENT_TEMPERATURE 25.0        // Temperatura otoczenia
#define BOILING_TEMPERATURE     100.0       // Temperatura wrzenia dla wody

typedef struct kettle_t
{
    struct
    {
        float target;
        float min_hold;
        float max_hold;
        float environment;
        float current;
        float delta;
    }temperature;

    union kettle_status
    {
        unsigned int all;
        struct kettle_status_bits
        {
            unsigned int ON:1;
            unsigned int HOLD:1;
            unsigned int HEAT:1;
        }bit;
    }status;
   struct kettle_gui
   {
        float min_hold_temperature_target;
        float max_hold_temperature_target;
        float current_temperature;
        union gui_controls
        {
            unsigned int all;
            struct gui_controls_bits
            {
                unsigned int ON:1;
                unsigned int HOLD:1;
                unsigned int HEAT:1;
            }bit;
        }controls;
    }gui;
}kettle_t;

void kettle_init(kettle_t *self);
void kettle_thermal_calc(kettle_t *self);
void kettle_gui_init(kettle_t *self);
void synch_gui(kettle_t *self);

#endif
