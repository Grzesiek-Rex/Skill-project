#include "kettle.h"
#include "F28x_Project.h"

void kettle_thermal_calc(kettle_t *self)
{
    if(self->status.bit.HOLD)
    {
        if(self->status.bit.HEAT)
        {
            self->temperature.current += self->temperature.delta;
            if(self->temperature.current > self->temperature.max_hold)
            {
                self->temperature.current = self->temperature.current;
            }
        }
        else
        {
            self->temperature.current -= self->temperature.delta;
            if(self->temperature.current < self->temperature.environment)
            {
                self->temperature.current = self->temperature.environment;
            }
        }
    }
    else
    {
        if(self->status.bit.HEAT)
        {
            self->temperature.current += self->temperature.delta;
            if(self->temperature.current > self->temperature.target)
            {
                self->temperature.current = self->temperature.target;
            }
        }
        else
        {
            self->temperature.current -= self->temperature.delta;
            if(self->temperature.current < self->temperature.environment)
            {
                self->temperature.current = self->temperature.environment;
            }
        }
    }
}

void kettle_init(kettle_t *self)
{
    self->temperature.target = BOILING_TEMPERATURE;
    self->temperature.environment = ENVIRONMENT_TEMPERATURE;
    self->temperature.min_hold = ENVIRONMENT_TEMPERATURE;
    self->temperature.max_hold = ENVIRONMENT_TEMPERATURE;
    self->temperature.current = ENVIRONMENT_TEMPERATURE;
    self->temperature.delta = DELTA_TEMPERATURE;
    self->status.all = 0;
}

void kettle_gui_init(kettle_t *self)
{
    self->gui.current_temperature = self->temperature.current;
    self->gui.max_hold_temperature_target = self->temperature.max_hold;
    self->gui.min_hold_temperature_target = self->temperature.min_hold;
    self->gui.controls.all = self->status.all;
}

void synch_gui(kettle_t *self)
{
    if(self->gui.max_hold_temperature_target < self->gui.min_hold_temperature_target)
        self->gui.max_hold_temperature_target = self->gui.min_hold_temperature_target;
    self->temperature.max_hold = self->gui.max_hold_temperature_target;
    self->temperature.min_hold = self->gui.min_hold_temperature_target;

    self->status.bit.ON = self->gui.controls.bit.ON;
    self->status.bit.HOLD = self->gui.controls.bit.HOLD;


    if(self->status.bit.ON)
    {
        if(self->status.bit.HOLD)
        {
            if((self->temperature.current < self->temperature.min_hold))
            {
                self->status.bit.HEAT = 1;
            }
            if(self->temperature.current >= self->temperature.max_hold)
            {
                self->status.bit.HEAT = 0;
            }
        }
        else
        {
            if((self->temperature.current < self->temperature.target))
            {
                self->status.bit.HEAT = 1;
            }
            else
            {
                self->gui.controls.bit.ON = 0;
                self->status.bit.ON = 0;
                self->status.bit.HEAT = 0;
            }
        }
    }
    else
    {
        self->status.bit.HEAT = 0;
    }

    self->gui.controls.bit.HEAT = self->status.bit.HEAT;
    self->gui.current_temperature = self->temperature.current;
}
