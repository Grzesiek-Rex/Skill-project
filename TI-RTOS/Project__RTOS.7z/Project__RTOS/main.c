#include <xdc/std.h>
#include <xdc/runtime/Log.h>
#include <xdc/runtime/System.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include "F28x_Project.h"
#include <xdc/cfg/global.h>
#include <xdc/runtime/Timestamp.h>
#include <kettle.h>

kettle_t kettle;
int count_calc_temp = 0;
int count_sych_gui = 0;
int count_toggle = 0;
void hardware_init();

void kettle_calc()
{
    Log_info1("TEMP CALCULATE = [%u] TIMES", count_calc_temp++);
    kettle_thermal_calc(&kettle);
}

void kettle_synch()
{
    Log_info1("GUI SYNCH = [%u] TIMES", count_sych_gui++);
    synch_gui(&kettle);
}

void ToggleLed()
{
    if(kettle.status.bit.HEAT)
    {
        GpioDataRegs.GPASET.bit.GPIO31 = 1;         //Idle mode - BLUE LED
        GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;      //Heat mode - RED LED

    }
    else
    {
        GpioDataRegs.GPATOGGLE.bit.GPIO31 = 1;      //Idle mode - BLUE LED
        GpioDataRegs.GPBSET.bit.GPIO34 = 1;         //Heat mode - RED LED
    }
    Log_info1("LED TOGGLED = [%u] TIMES", count_toggle++);
    DELAY_US(80000);
}

Int main()
{
    kettle_init(&kettle);
    kettle_gui_init(&kettle);
    hardware_init();
    BIOS_start();
    return(0);
}

void hardware_init()
{
    InitSysCtrl();
    EALLOW;
    GpioCtrlRegs.GPAMUX2.bit.GPIO31 = 0;
    GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;
    GpioCtrlRegs.GPADIR.bit.GPIO31 = 1;
    GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;
    EDIS;
    GpioDataRegs.GPACLEAR.bit.GPIO31 = 1;   //Idle mode - BLUE LED
    GpioDataRegs.GPBSET.bit.GPIO34 = 1;     //Heat mode - RED LED
    InitCpuTimers();
    ConfigCpuTimer(&CpuTimer0, 20, 2000000);
    ConfigCpuTimer(&CpuTimer1, 20, 4000000);
    CpuTimer0Regs.TCR.all = 0x4001;
    CpuTimer1Regs.TCR.all = 0x4001;
}

void Timer_ISR()
{
    Swi_post(TempSwi);
}

void Timer_ISR2()
{
    Swi_post(SynchData);
}

